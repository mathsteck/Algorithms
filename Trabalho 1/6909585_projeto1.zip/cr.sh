make
echo test.txt 2 | ./main

